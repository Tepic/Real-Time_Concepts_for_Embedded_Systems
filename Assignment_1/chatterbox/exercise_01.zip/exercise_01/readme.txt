For MSVC: open project from .\FreeRTOS\Chatterbox-App\WIN32-MSVC\WIN32.sln
